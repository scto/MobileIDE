#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_$jniPackageName_MainActivity_stringFromJNI(
    JNIEnv* env,
    jobject /* this */) {
    std::string hello = "Hello from Native C++ !!";
    return env->NewStringUTF(hello.c_str());
}
